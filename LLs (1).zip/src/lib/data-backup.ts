// This is a backup of the original data.ts before replacing images
// All image URLs have been replaced with placeholders for easier customization
